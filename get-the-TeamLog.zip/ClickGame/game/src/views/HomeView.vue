<template>
  <div class="home">
    <HelloWorld/>
    <CustomAlert></CustomAlert>
  </div>
</template>

<script>
// @ is an alias to /src
import HelloWorld from '@/components/HelloWorld.vue'
import CustomAlert from '@/components/CustomAlert.vue'

export default {
  name: 'HomeView',
  components: {
    HelloWorld,
    CustomAlert,
  }
}
</script>
